# Atrans

### Atrans是什么
Atrans(Android xml translate) Android项目layout drawable resources xml资源转Harmony对应json 或xml资源文件

### 配置环境变量 
*为了在cmd窗口可以从任意路径访问`atrans`, 需要将`atrans.bat`所在目录添加到环境变量path中*.
1. 新建环境变量key:`atranspath`, value:`atrans.bat所在目录`
2. 将`%atranspath%`添加到环境变量path中
```path
atranspath='atrans.bat所在目录'
path=%atranspath%;
```
2. 打开命令行cmd窗口, 键入 trans /?, 如提示使用使用帮助指南则表示配置成功, 否则需要检查变量配置是否正确

### 其他
[详细说明&解析器配置](https://github.com/yuxiangxin/Atrans)    
[问题反馈与建议](https://github.com/yuxiangxin/Atrans/issues/new)
